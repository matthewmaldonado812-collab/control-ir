# Control IR — control remoto infrarrojo para TV (versión 1.1)

App Android (Kotlin + Jetpack Compose). Solo infrarrojo: no tiene permiso de internet.
Marcas: Samsung, LG, Sony (verificadas), Panasonic, Philips, Toshiba, Hitachi, JVC, Sanyo, Insignia, Emerson,
Magnavox, Coby, Vivax, ADLER, Loewe, y **Milexus** / **Otra marca** con búsqueda de código.
Los códigos salen de `app/src/main/assets/profiles.txt`.

Buscar código: elige la marca, toca «Buscar código», apunta al TV y toca «¡Funcionó!» cuando reaccione.
Requiere un teléfono con transmisor infrarrojo.
