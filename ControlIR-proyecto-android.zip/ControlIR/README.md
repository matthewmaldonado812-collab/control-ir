# Control IR — control remoto infrarrojo para TV

App Android (Kotlin + Jetpack Compose). Solo infrarrojo: no tiene permiso de internet.
Marcas: Samsung, LG y Sony. Requiere un teléfono con transmisor infrarrojo.

Cómo obtener el APK: sube el ZIP a un repositorio de GitHub y agrega `.github/workflows/build.yml`
(el código está en el chat). Al terminar, el APK queda en **Releases**.
