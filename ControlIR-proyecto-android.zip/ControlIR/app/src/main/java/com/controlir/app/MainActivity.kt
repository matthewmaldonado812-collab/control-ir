package com.controlir.app

import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.view.HapticFeedbackConstants
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

// ---------- Señales infrarrojas (tiempos en microsegundos) ----------

class IrCode(val freq: Int, val pattern: IntArray)

// NEC y Samsung: pulso de 560 us; bit 1 = 1690 us de silencio, bit 0 = 560 us.
// Cada byte se envía empezando por el bit menos significativo.
private fun pulseDistance(hMark: Int, hSpace: Int, bytes: IntArray): IrCode {
    val p = ArrayList<Int>()
    p.add(hMark)
    p.add(hSpace)
    for (b in bytes) {
        for (i in 0 until 8) {
            p.add(560)
            p.add(if (((b shr i) and 1) == 1) 1690 else 560)
        }
    }
    p.add(560)
    return IrCode(38000, p.toIntArray())
}

// LG y otras marcas NEC: dirección, dirección invertida, comando, comando invertido.
fun nec(addr: Int, cmd: Int): IrCode =
    pulseDistance(9000, 4500, intArrayOf(addr and 0xFF, addr.inv() and 0xFF, cmd and 0xFF, cmd.inv() and 0xFF))

// Samsung: dirección 0x07 repetida, comando y comando invertido.
fun samsung(cmd: Int): IrCode =
    pulseDistance(4500, 4500, intArrayOf(0x07, 0x07, cmd and 0xFF, cmd.inv() and 0xFF))

// Sony SIRC de 12 bits (7 de comando + 5 de dispositivo), portadora de 40 kHz,
// la trama se envía 3 veces con 45 ms entre inicios.
fun sony(cmd: Int, dev: Int = 1): IrCode {
    val frame = ArrayList<Int>()
    frame.add(2400)
    frame.add(600)
    for (i in 0 until 7) {
        frame.add(if (((cmd shr i) and 1) == 1) 1200 else 600)
        frame.add(600)
    }
    for (i in 0 until 5) {
        frame.add(if (((dev shr i) and 1) == 1) 1200 else 600)
        frame.add(600)
    }
    val duration = frame.sum()
    val p = ArrayList<Int>()
    repeat(3) {
        p.addAll(frame)
        p[p.size - 1] = p[p.size - 1] + (45000 - duration)
    }
    return IrCode(40000, p.toIntArray())
}

// ---------- Marcas y teclas ----------

enum class Key {
    POWER, SOURCE, MUTE, VOL_UP, VOL_DOWN, CH_UP, CH_DOWN,
    UP, DOWN, LEFT, RIGHT, OK, MENU, HOME, BACK, EXIT,
    D0, D1, D2, D3, D4, D5, D6, D7, D8, D9
}

class Brand(val name: String, val codes: Map<Key, IrCode>)

private val digitKeys = listOf(Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6, Key.D7, Key.D8, Key.D9)

private fun makeBrand(name: String, base: Map<Key, Int>, digits: IntArray, make: (Int) -> IrCode): Brand {
    val m = HashMap<Key, IrCode>()
    for ((k, c) in base) m[k] = make(c)
    for (n in 0..9) m[digitKeys[n]] = make(digits[n])
    return Brand(name, m)
}

val brands: List<Brand> = listOf(
    makeBrand(
        "Samsung",
        mapOf(
            Key.POWER to 0x02, Key.SOURCE to 0x01, Key.MUTE to 0x0F,
            Key.VOL_UP to 0x07, Key.VOL_DOWN to 0x0B, Key.CH_UP to 0x12, Key.CH_DOWN to 0x10,
            Key.UP to 0x60, Key.DOWN to 0x61, Key.LEFT to 0x65, Key.RIGHT to 0x62, Key.OK to 0x68,
            Key.MENU to 0x1A, Key.HOME to 0x79, Key.BACK to 0x58, Key.EXIT to 0x2D,
        ),
        intArrayOf(0x11, 0x04, 0x05, 0x06, 0x08, 0x09, 0x0A, 0x0C, 0x0D, 0x0E),
    ) { samsung(it) },
    makeBrand(
        "LG",
        mapOf(
            Key.POWER to 0x08, Key.SOURCE to 0x0B, Key.MUTE to 0x09,
            Key.VOL_UP to 0x02, Key.VOL_DOWN to 0x03, Key.CH_UP to 0x00, Key.CH_DOWN to 0x01,
            Key.UP to 0x40, Key.DOWN to 0x41, Key.LEFT to 0x07, Key.RIGHT to 0x06, Key.OK to 0x44,
            Key.MENU to 0x43, Key.HOME to 0x7C, Key.BACK to 0x28, Key.EXIT to 0x5B,
        ),
        IntArray(10) { 0x10 + it },
    ) { nec(0x04, it) },
    makeBrand(
        "Sony",
        mapOf(
            Key.POWER to 21, Key.SOURCE to 37, Key.MUTE to 20,
            Key.VOL_UP to 18, Key.VOL_DOWN to 19, Key.CH_UP to 16, Key.CH_DOWN to 17,
            Key.UP to 116, Key.DOWN to 117, Key.LEFT to 52, Key.RIGHT to 51, Key.OK to 101,
            Key.MENU to 96, Key.HOME to 96, Key.BACK to 99, Key.EXIT to 99,
        ),
        IntArray(10) { if (it == 0) 9 else it - 1 },
    ) { sony(it) },
)

// ---------- Transmisor infrarrojo del teléfono ----------

object IrSender {
    private var manager: ConsumerIrManager? = null
    private val exec = Executors.newSingleThreadExecutor()

    fun init(ctx: Context) {
        manager = try {
            ctx.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        } catch (e: Exception) {
            null
        }
    }

    fun available(): Boolean = try {
        manager?.hasIrEmitter() == true
    } catch (e: Exception) {
        false
    }

    fun send(code: IrCode) {
        val m = manager ?: return
        exec.execute {
            try {
                m.transmit(pickFreq(m, code.freq), code.pattern)
            } catch (e: Exception) {
            }
        }
    }

    // Si el emisor no soporta exactamente la frecuencia, usa la más cercana.
    private fun pickFreq(m: ConsumerIrManager, f: Int): Int {
        val ranges = m.carrierFrequencies ?: return f
        if (ranges.isEmpty() || ranges.any { f >= it.minFrequency && f <= it.maxFrequency }) return f
        return ranges
            .map { if (f < it.minFrequency) it.minFrequency else it.maxFrequency }
            .minByOrNull { kotlin.math.abs(it - f) } ?: f
    }
}

// ---------- Pantalla ----------

private val Dark = Color(0xFF0F1115)
private val BtnColor = Color(0xFF23262D)
private val Accent = Color(0xFFE53935)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.parseColor("#0F1115")
        window.navigationBarColor = android.graphics.Color.parseColor("#0F1115")
        IrSender.init(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent)) { RemoteScreen() }
        }
    }
}

// Botón base: envía al tocar; si repeat=true, repite mientras se mantiene presionado.
@Composable
fun KeyBtn(
    modifier: Modifier = Modifier,
    color: Color = BtnColor,
    shape: Shape = RoundedCornerShape(16.dp),
    repeat: Boolean = false,
    onSend: () -> Unit,
    content: @Composable () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val send by rememberUpdatedState(onSend)
    Box(
        modifier
            .clip(shape)
            .background(color)
            .pointerInput(repeat) {
                detectTapGestures(onPress = {
                    send()
                    val job = if (repeat) {
                        scope.launch {
                            delay(450)
                            while (true) {
                                send()
                                delay(140)
                            }
                        }
                    } else null
                    tryAwaitRelease()
                    job?.cancel()
                })
            },
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
fun TextKey(
    label: String,
    key: Key,
    press: (Key) -> Unit,
    modifier: Modifier = Modifier,
    repeat: Boolean = false,
    fontSize: TextUnit = 15.sp,
) {
    KeyBtn(modifier.height(56.dp), repeat = repeat, onSend = { press(key) }) {
        Text(label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = fontSize)
    }
}

@Composable
fun IconKey(
    icon: ImageVector,
    description: String,
    key: Key,
    press: (Key) -> Unit,
    modifier: Modifier = Modifier,
    repeat: Boolean = false,
) {
    KeyBtn(modifier, repeat = repeat, onSend = { press(key) }) {
        Icon(icon, description, tint = Color.White)
    }
}

@Composable
fun RemoteScreen() {
    val ctx = LocalContext.current
    val view = LocalView.current
    val prefs = remember { ctx.getSharedPreferences("ir", Context.MODE_PRIVATE) }
    var idx by remember { mutableIntStateOf(prefs.getInt("brand", 0).coerceIn(0, brands.lastIndex)) }
    val hasIr = remember { IrSender.available() }
    val brand = brands[idx]
    val press: (Key) -> Unit = { k ->
        view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        brand.codes[k]?.let { IrSender.send(it) }
    }

    Surface(color = Dark, contentColor = Color.White, modifier = Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("Control remoto IR", fontSize = 20.sp, fontWeight = FontWeight.Bold)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                brands.forEachIndexed { i, b ->
                    FilterChip(
                        selected = i == idx,
                        onClick = {
                            idx = i
                            prefs.edit().putInt("brand", i).apply()
                        },
                        label = { Text(b.name) },
                    )
                }
            }

            if (!hasIr) {
                Text(
                    "Este teléfono no tiene transmisor infrarrojo, así que los botones no pueden enviar señal.",
                    color = Color(0xFFFFB4AB), fontSize = 13.sp, textAlign = TextAlign.Center,
                )
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                KeyBtn(Modifier.weight(1f).height(56.dp), color = Accent, onSend = { press(Key.POWER) }) {
                    Icon(Icons.Default.PowerSettingsNew, "Encender o apagar", tint = Color.White)
                }
                TextKey("FUENTE", Key.SOURCE, press, Modifier.weight(1f))
                TextKey("SILENCIO", Key.MUTE, press, Modifier.weight(1f), fontSize = 13.sp)
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("VOLUMEN", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                    TextKey("+", Key.VOL_UP, press, Modifier.fillMaxWidth(), repeat = true, fontSize = 22.sp)
                    TextKey("−", Key.VOL_DOWN, press, Modifier.fillMaxWidth(), repeat = true, fontSize = 22.sp)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("CANAL", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                    TextKey("+", Key.CH_UP, press, Modifier.fillMaxWidth(), repeat = true, fontSize = 22.sp)
                    TextKey("−", Key.CH_DOWN, press, Modifier.fillMaxWidth(), repeat = true, fontSize = 22.sp)
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                IconKey(Icons.Default.KeyboardArrowUp, "Arriba", Key.UP, press, Modifier.size(72.dp), repeat = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconKey(Icons.Default.KeyboardArrowLeft, "Izquierda", Key.LEFT, press, Modifier.size(72.dp), repeat = true)
                    KeyBtn(Modifier.size(72.dp), color = Accent, shape = CircleShape, onSend = { press(Key.OK) }) {
                        Text("OK", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    IconKey(Icons.Default.KeyboardArrowRight, "Derecha", Key.RIGHT, press, Modifier.size(72.dp), repeat = true)
                }
                IconKey(Icons.Default.KeyboardArrowDown, "Abajo", Key.DOWN, press, Modifier.size(72.dp), repeat = true)
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TextKey("ATRÁS", Key.BACK, press, Modifier.weight(1f), fontSize = 13.sp)
                KeyBtn(Modifier.weight(1f).height(56.dp), onSend = { press(Key.HOME) }) {
                    Icon(Icons.Default.Home, "Inicio", tint = Color.White)
                }
                TextKey("MENÚ", Key.MENU, press, Modifier.weight(1f), fontSize = 13.sp)
                TextKey("SALIR", Key.EXIT, press, Modifier.weight(1f), fontSize = 13.sp)
            }

            listOf(listOf(1, 2, 3), listOf(4, 5, 6), listOf(7, 8, 9)).forEach { r ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    r.forEach { n -> TextKey("$n", digitKeys[n], press, Modifier.weight(1f), fontSize = 20.sp) }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Spacer(Modifier.weight(1f))
                TextKey("0", Key.D0, press, Modifier.weight(1f), fontSize = 20.sp)
                Spacer(Modifier.weight(1f))
            }

            Text(
                "Apunta la parte superior del teléfono (donde está el emisor infrarrojo) hacia el televisor.",
                color = Color.Gray, fontSize = 12.sp, textAlign = TextAlign.Center,
            )
        }
    }
}
