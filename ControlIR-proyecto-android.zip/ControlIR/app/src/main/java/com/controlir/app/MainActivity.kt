package com.controlir.app

import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

// ---------- Transmisor infrarrojo del teléfono ----------

object IrSender {
    private var manager: ConsumerIrManager? = null
    private val exec = Executors.newSingleThreadExecutor()

    fun init(ctx: Context) {
        manager = try {
            ctx.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        } catch (e: Exception) {
            null
        }
    }

    fun available(): Boolean = try {
        manager?.hasIrEmitter() == true
    } catch (e: Exception) {
        false
    }

    fun send(code: IrCode) {
        val m = manager ?: return
        exec.execute {
            try {
                m.transmit(pickFreq(m, code.freq), code.pattern)
            } catch (e: Exception) {
            }
        }
    }

    // Si el emisor no soporta exactamente la frecuencia, usa la más cercana.
    private fun pickFreq(m: ConsumerIrManager, f: Int): Int {
        val ranges = m.carrierFrequencies ?: return f
        if (ranges.isEmpty() || ranges.any { f >= it.minFrequency && f <= it.maxFrequency }) return f
        return ranges
            .map { if (f < it.minFrequency) it.minFrequency else it.maxFrequency }
            .minByOrNull { kotlin.math.abs(it - f) } ?: f
    }
}

// ---------- Marcas ----------

private val POPULAR = listOf(
    "Samsung", "LG", "Sony", "Milexus", "Panasonic", "Philips", "Toshiba", "Hitachi", "JVC",
    "Sanyo", "Insignia", "Emerson", "Magnavox", "Coby", "Vivax", "ADLER", "Loewe",
)

fun chipsOf(profiles: List<Profile>): List<String> {
    val names = profiles.map { it.name }.distinct()
    val first = POPULAR.filter { it == "Milexus" || it in names }
    val rest = names.filter { it !in first }.sorted()
    return first + rest + "Otra marca"
}

// Códigos de encendido que se prueban uno por uno al buscar el código de un TV.
fun scanListFor(profiles: List<Profile>, chip: String): List<Profile> {
    val seen = HashSet<String>()
    val out = ArrayList<Profile>()
    for (p in profiles.sortedBy { if (it.name == chip) 0 else 1 }) {
        if (seen.add("${p.proto}|${p.dev}|${p.sub}|${p.cmds[Key.POWER.ordinal]}")) out.add(p)
    }
    return out
}

// ---------- Pantalla ----------

private val Dark = Color(0xFF0F1115)
private val BtnColor = Color(0xFF23262D)
private val Accent = Color(0xFFE53935)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.parseColor("#0F1115")
        window.navigationBarColor = android.graphics.Color.parseColor("#0F1115")
        IrSender.init(applicationContext)
        val lines = try {
            assets.open("profiles.txt").bufferedReader().readLines()
        } catch (e: Exception) {
            emptyList()
        }
        val profiles = Ir.parseProfiles(lines)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent)) { RemoteScreen(profiles) }
        }
    }
}

// Botón base: envía al tocar; si repeat=true, repite mientras se mantiene presionado.
@Composable
fun KeyBtn(
    modifier: Modifier = Modifier,
    color: Color = BtnColor,
    shape: Shape = RoundedCornerShape(16.dp),
    repeat: Boolean = false,
    onSend: () -> Unit,
    content: @Composable () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val send by rememberUpdatedState(onSend)
    Box(
        modifier
            .clip(shape)
            .background(color)
            .pointerInput(repeat) {
                detectTapGestures(onPress = {
                    send()
                    val job = if (repeat) {
                        scope.launch {
                            delay(450)
                            while (true) {
                                send()
                                delay(140)
                            }
                        }
                    } else null
                    tryAwaitRelease()
                    job?.cancel()
                })
            },
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
fun TextKey(
    label: String,
    key: Key,
    press: (Key) -> Unit,
    modifier: Modifier = Modifier,
    repeat: Boolean = false,
    fontSize: TextUnit = 15.sp,
) {
    KeyBtn(modifier.height(56.dp), repeat = repeat, onSend = { press(key) }) {
        Text(label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = fontSize)
    }
}

@Composable
fun IconKey(
    icon: ImageVector,
    description: String,
    key: Key,
    press: (Key) -> Unit,
    modifier: Modifier = Modifier,
    repeat: Boolean = false,
) {
    KeyBtn(modifier, repeat = repeat, onSend = { press(key) }) {
        Icon(icon, description, tint = Color.White)
    }
}

// Prueba el botón de encendido de cada código hasta que el TV reaccione.
@Composable
fun ScanDialog(chip: String, list: List<Profile>, onFound: (Profile) -> Unit, onClose: () -> Unit) {
    var i by remember { mutableIntStateOf(0) }
    var auto by remember { mutableStateOf(true) }
    LaunchedEffect(i) {
        list[i].code(Key.POWER, 0)?.let { IrSender.send(it) }
    }
    LaunchedEffect(i, auto) {
        if (auto) {
            delay(1800)
            if (i < list.lastIndex) i++ else auto = false
        }
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Buscar código de $chip") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Apunta el teléfono al televisor. Se prueba el botón de encendido de cada código. " +
                        "Cuando el TV reaccione, toca «¡Funcionó!». Si se pasa de largo, toca «Anterior».",
                    fontSize = 13.sp,
                )
                Text("Probando ${i + 1} de ${list.size}: ${list[i].label}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                LinearProgressIndicator(progress = { (i + 1f) / list.size }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { auto = false; if (i > 0) i-- }) { Text("Anterior") }
                    TextButton(onClick = { auto = false; if (i < list.lastIndex) i++ }) { Text("Siguiente") }
                    TextButton(onClick = { auto = !auto }) { Text(if (auto) "Pausar" else "Automático") }
                }
            }
        },
        confirmButton = { Button(onClick = { onFound(list[i]) }) { Text("¡Funcionó!") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cerrar") } },
    )
}

@Composable
fun RemoteScreen(profiles: List<Profile>) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val prefs = remember { ctx.getSharedPreferences("ir", Context.MODE_PRIVATE) }
    val chips = remember { chipsOf(profiles) }
    var sel by remember { mutableStateOf(prefs.getString("sel", null)?.takeIf { it in chips } ?: chips[0]) }
    val bind = remember {
        mutableStateMapOf<String, String>().apply {
            chips.forEach { c -> prefs.getString("bind_$c", null)?.let { put(c, it) } }
        }
    }
    val hasIr = remember { IrSender.available() }
    var msg by remember { mutableStateOf("") }
    var scanOpen by remember { mutableStateOf(false) }
    var last by remember { mutableLongStateOf(0L) }
    var tog by remember { mutableIntStateOf(0) }

    val profile: Profile? = bind[sel]?.let { id -> profiles.find { it.id == id } }
        ?: profiles.firstOrNull { it.name == sel }

    val press: (Key) -> Unit = { k ->
        view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        val p = profile
        if (p == null) {
            msg = "«$sel» aún no tiene código. Toca «Buscar código» y apunta al televisor."
        } else {
            val now = SystemClock.uptimeMillis()
            if (now - last > 250) tog = tog xor 1
            last = now
            val c = p.code(k, tog)
            if (c == null) {
                msg = "Este código no incluye ese botón."
            } else {
                if (msg.isNotEmpty()) msg = ""
                IrSender.send(c)
            }
        }
    }

    if (scanOpen) {
        val list = remember(sel) { scanListFor(profiles, sel) }
        if (list.isNotEmpty()) {
            ScanDialog(
                chip = sel,
                list = list,
                onFound = { p ->
                    bind[sel] = p.id
                    prefs.edit().putString("bind_$sel", p.id).apply()
                    scanOpen = false
                    msg = "Listo: «$sel» usará ${p.label}. Prueba el volumen y el canal."
                },
                onClose = { scanOpen = false },
            )
        }
    }

    Surface(color = Dark, contentColor = Color.White, modifier = Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("Control remoto IR", fontSize = 20.sp, fontWeight = FontWeight.Bold)

            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                chips.forEach { c ->
                    FilterChip(
                        selected = c == sel,
                        onClick = {
                            sel = c
                            msg = ""
                            prefs.edit().putString("sel", c).apply()
                        },
                        label = { Text(c) },
                    )
                }
            }

            Text(
                if (profile == null) "Sin código para «$sel»" else "Código: ${profile.label}",
                color = Color.Gray, fontSize = 12.sp, textAlign = TextAlign.Center,
            )
            Button(onClick = { scanOpen = true }, colors = ButtonDefaults.buttonColors(containerColor = BtnColor)) {
                Text("Buscar código para «$sel»")
            }

            if (!hasIr) {
                Text(
                    "Este teléfono no tiene transmisor infrarrojo, así que los botones no pueden enviar señal.",
                    color = Color(0xFFFFB4AB), fontSize = 13.sp, textAlign = TextAlign.Center,
                )
            }
            if (msg.isNotEmpty()) {
                Text(msg, color = Color(0xFFFFD54F), fontSize = 13.sp, textAlign = TextAlign.Center)
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                KeyBtn(Modifier.weight(1f).height(56.dp), color = Accent, onSend = { press(Key.POWER) }) {
                    Icon(Icons.Default.PowerSettingsNew, "Encender o apagar", tint = Color.White)
                }
                TextKey("FUENTE", Key.SOURCE, press, Modifier.weight(1f))
                TextKey("SILENCIO", Key.MUTE, press, Modifier.weight(1f), fontSize = 13.sp)
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("VOLUMEN", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                    TextKey("+", Key.VOL_UP, press, Modifier.fillMaxWidth(), repeat = true, fontSize = 22.sp)
                    TextKey("−", Key.VOL_DOWN, press, Modifier.fillMaxWidth(), repeat = true, fontSize = 22.sp)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("CANAL", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                    TextKey("+", Key.CH_UP, press, Modifier.fillMaxWidth(), repeat = true, fontSize = 22.sp)
                    TextKey("−", Key.CH_DOWN, press, Modifier.fillMaxWidth(), repeat = true, fontSize = 22.sp)
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                IconKey(Icons.Default.KeyboardArrowUp, "Arriba", Key.UP, press, Modifier.size(72.dp), repeat = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconKey(Icons.Default.KeyboardArrowLeft, "Izquierda", Key.LEFT, press, Modifier.size(72.dp), repeat = true)
                    KeyBtn(Modifier.size(72.dp), color = Accent, shape = CircleShape, onSend = { press(Key.OK) }) {
                        Text("OK", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    IconKey(Icons.Default.KeyboardArrowRight, "Derecha", Key.RIGHT, press, Modifier.size(72.dp), repeat = true)
                }
                IconKey(Icons.Default.KeyboardArrowDown, "Abajo", Key.DOWN, press, Modifier.size(72.dp), repeat = true)
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TextKey("ATRÁS", Key.BACK, press, Modifier.weight(1f), fontSize = 13.sp)
                KeyBtn(Modifier.weight(1f).height(56.dp), onSend = { press(Key.HOME) }) {
                    Icon(Icons.Default.Home, "Inicio", tint = Color.White)
                }
                TextKey("MENÚ", Key.MENU, press, Modifier.weight(1f), fontSize = 13.sp)
                TextKey("SALIR", Key.EXIT, press, Modifier.weight(1f), fontSize = 13.sp)
            }

            val digits = listOf(Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6, Key.D7, Key.D8, Key.D9)
            digits.chunked(3).forEachIndexed { r, row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEachIndexed { c, k -> TextKey("${r * 3 + c + 1}", k, press, Modifier.weight(1f), fontSize = 20.sp) }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Spacer(Modifier.weight(1f))
                TextKey("0", Key.D0, press, Modifier.weight(1f), fontSize = 20.sp)
                Spacer(Modifier.weight(1f))
            }

            Text(
                "Apunta la parte superior del teléfono (donde está el emisor infrarrojo) hacia el televisor.",
                color = Color.Gray, fontSize = 12.sp, textAlign = TextAlign.Center,
            )
        }
    }
}
