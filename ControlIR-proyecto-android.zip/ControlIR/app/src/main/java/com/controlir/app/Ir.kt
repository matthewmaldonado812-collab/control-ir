package com.controlir.app

// Todo lo de este archivo es Kotlin puro (sin Android) para poder probarlo aparte.

class IrCode(val freq: Int, val pattern: IntArray)

enum class Key {
    POWER, SOURCE, MUTE, VOL_UP, VOL_DOWN, CH_UP, CH_DOWN,
    UP, DOWN, LEFT, RIGHT, OK, MENU, HOME, BACK, EXIT,
    D0, D1, D2, D3, D4, D5, D6, D7, D8, D9
}

// Un "perfil" es un juego de códigos de un control: protocolo + dispositivo + un comando por tecla.
class Profile(val name: String, val proto: String, val dev: Int, val sub: Int, val cmds: IntArray) {
    val label: String get() = "$name · $proto $dev" + (if (sub >= 0) ",$sub" else "")
    val id: String get() = "$proto|$dev|$sub|$name"
    fun has(k: Key): Boolean = cmds[k.ordinal] >= 0
    fun code(k: Key, toggle: Int = 0): IrCode? {
        val c = cmds[k.ordinal]
        return if (c < 0) null else Ir.build(proto, dev, sub, c, toggle)
    }
}

object Ir {
    private fun inv(x: Int) = x.inv() and 0xFF

    fun parseProfiles(lines: List<String>): List<Profile> {
        val out = ArrayList<Profile>()
        for (raw in lines) {
            val l = raw.trim()
            if (l.isEmpty() || l.startsWith("#")) continue
            val f = l.split("|")
            if (f.size < 5) continue
            val cmds = f[4].split(",").map { it.trim().toInt() }
            if (cmds.size != Key.values().size) continue
            out.add(Profile(f[0], f[1], f[2].toInt(), f[3].toInt(), cmds.toIntArray()))
        }
        return out
    }

    // Protocolos de "distancia de pulso": cada byte se envía empezando por el bit menos significativo.
    private fun pulseDistance(freq: Int, hMark: Int, hSpace: Int, mark: Int, zero: Int, one: Int, bytes: IntArray, stop: Int): IrCode {
        val p = ArrayList<Int>()
        p.add(hMark)
        p.add(hSpace)
        for (b in bytes) {
            for (i in 0 until 8) {
                p.add(mark)
                p.add(if (((b shr i) and 1) == 1) one else zero)
            }
        }
        p.add(stop)
        return IrCode(freq, p.toIntArray())
    }

    // Sony SIRC: 40 kHz, la trama se envía 3 veces con 45 ms entre inicios.
    private fun sony(cmd: Int, dev: Int, devBits: Int, sub: Int, subBits: Int): IrCode {
        val frame = ArrayList<Int>()
        frame.add(2400)
        frame.add(600)
        fun bits(v: Int, n: Int) {
            for (i in 0 until n) {
                frame.add(if (((v shr i) and 1) == 1) 1200 else 600)
                frame.add(600)
            }
        }
        bits(cmd, 7)
        bits(dev, devBits)
        if (subBits > 0) bits(sub, subBits)
        val duration = frame.sum()
        val p = ArrayList<Int>()
        repeat(3) {
            p.addAll(frame)
            p[p.size - 1] = p[p.size - 1] + maxOf(0, 45000 - duration)
        }
        return IrCode(40000, p.toIntArray())
    }

    // Philips RC-5: 36 kHz, codificación Manchester de 889 us por medio bit.
    private fun rc5(dev: Int, cmd: Int, toggle: Int): IrCode {
        val bits = ArrayList<Int>()
        bits.add(1)
        bits.add(if ((cmd and 0x40) != 0) 0 else 1)
        bits.add(toggle and 1)
        for (i in 4 downTo 0) bits.add((dev shr i) and 1)
        for (i in 5 downTo 0) bits.add((cmd shr i) and 1)
        val seg = ArrayList<Pair<Boolean, Int>>()
        fun half(level: Boolean) {
            if (seg.isNotEmpty() && seg[seg.size - 1].first == level) {
                seg[seg.size - 1] = Pair(level, seg[seg.size - 1].second + 889)
            } else seg.add(Pair(level, 889))
        }
        for (b in bits) {
            if (b == 1) { half(false); half(true) } else { half(true); half(false) }
        }
        if (!seg[0].first) seg.removeAt(0)
        return IrCode(36000, seg.map { it.second }.toIntArray())
    }

    fun build(proto: String, dev: Int, sub: Int, cmd: Int, toggle: Int = 0): IrCode? {
        val s = if (sub >= 0) sub and 0xFF else inv(dev)
        return when (proto) {
            "NEC" -> pulseDistance(38000, 9000, 4500, 560, 560, 1690, intArrayOf(dev and 0xFF, s, cmd and 0xFF, inv(cmd)), 560)
            "NECX" -> pulseDistance(38000, 4500, 4500, 560, 560, 1690, intArrayOf(dev and 0xFF, s, cmd and 0xFF, inv(cmd)), 560)
            "PANASONIC" -> pulseDistance(37000, 3456, 1728, 432, 432, 1296,
                intArrayOf(0x02, 0x20, dev and 0xFF, maxOf(sub, 0) and 0xFF, cmd and 0xFF, (dev xor maxOf(sub, 0) xor cmd) and 0xFF), 432)
            "JVC" -> pulseDistance(38000, 8400, 4200, 525, 525, 1575, intArrayOf(dev and 0xFF, cmd and 0xFF), 525)
            "SONY12" -> sony(cmd, dev, 5, 0, 0)
            "SONY15" -> sony(cmd, dev, 8, 0, 0)
            "SONY20" -> sony(cmd, dev, 5, maxOf(sub, 0), 8)
            "RC5" -> rc5(dev, cmd, toggle)
            else -> null
        }
    }
}
